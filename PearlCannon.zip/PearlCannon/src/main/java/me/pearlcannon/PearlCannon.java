package me.pearlcannon;

import org.bukkit.FluidCollisionMode;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.entity.EnderPearl;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

public class PearlCannon extends JavaPlugin implements Listener {

    private NamespacedKey simulatedKey;
    private int maxTicks;
    private double timeMultiplier;
    private int extraDelay;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        maxTicks = getConfig().getInt("max-simulated-ticks", 1200);
        timeMultiplier = getConfig().getDouble("flight-time-multiplier", 1.0);
        extraDelay = getConfig().getInt("extra-delay-ticks", 2);
        simulatedKey = new NamespacedKey(this, "simulated");
        getServer().getPluginManager().registerEvents(this, this);
    }

    private record Result(Vector landPos, Vector landVel, int ticks, boolean leftLoaded) {}

    @EventHandler
    public void onLaunch(ProjectileLaunchEvent event) {
        if (!(event.getEntity() instanceof EnderPearl pearl)) return;
        if (!(pearl.getShooter() instanceof Player player)) return;
        if (pearl.getPersistentDataContainer().has(simulatedKey, PersistentDataType.BYTE)) return;

        World world = pearl.getWorld();
        Result r = simulate(world, pearl.getLocation().toVector(), pearl.getVelocity());
        // Not leaving loaded chunks, or never landing -> vanilla behaviour
        if (r == null || !r.leftLoaded()) return;

        pearl.remove();

        long delay = Math.max(1, Math.round(r.ticks() * timeMultiplier) + extraDelay);
        var landLoc = r.landPos().toLocation(world);

        getServer().getScheduler().runTaskLater(this, () ->
            world.getChunkAtAsync(landLoc).thenAccept(chunk ->
                world.spawn(landLoc, EnderPearl.class, p -> {
                    p.getPersistentDataContainer().set(simulatedKey, PersistentDataType.BYTE, (byte) 1);
                    p.setShooter(player);
                    p.setVelocity(r.landVel());
                })), delay);
    }

    /** Mirrors vanilla pearl physics: move, drag 0.99, gravity 0.03. Never loads chunks. */
    private Result simulate(World world, Vector startPos, Vector startVel) {
        Vector pos = startPos.clone();
        Vector vel = startVel.clone();
        boolean left = false;
        int minY = world.getMinHeight() - 64;

        for (int t = 1; t <= maxTicks; t++) {
            Vector next = pos.clone().add(vel);

            boolean startLoaded = loaded(world, pos);
            boolean nextLoaded = loaded(world, next);
            if (!nextLoaded) left = true;

            if (startLoaded && nextLoaded && vel.lengthSquared() > 1.0E-7) {
                RayTraceResult hit = world.rayTraceBlocks(pos.toLocation(world),
                        vel.clone().normalize(), vel.length(), FluidCollisionMode.NEVER, true);
                if (hit != null) {
                    return new Result(pos, vel, t, left);
                }
            }

            pos = next;
            if (pos.getY() < minY) return null; // void, pearl just dies
            vel.multiply(0.99);
            vel.setY(vel.getY() - 0.03);
        }
        return null;
    }

    private boolean loaded(World world, Vector v) {
        return world.isChunkLoaded(((int) Math.floor(v.getX())) >> 4, ((int) Math.floor(v.getZ())) >> 4);
    }
}
